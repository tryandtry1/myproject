const envList = [{"envId":"cloud1-4ggv4tv70a19c6b0","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}