package vo;

public class NoteCategory {
	int id;
	String category_text;
	int orders;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategory_text() {
		return category_text;
	}
	public void setCategory_text(String category_text) {
		this.category_text = category_text;
	}
	public int getOrders() {
		return orders;
	}
	public void setOrders(int orders) {
		this.orders = orders;
	}
	

}
